import json  # Standard library module to work with JSON data (encoding/decoding)
import boto3  # AWS SDK for Python, used to interact with AWS services
from decimal import Decimal  # Supports exact decimal arithmetic (useful for DynamoDB numbers)

# Initialise a DynamoDB resource using Boto3
dynamodb = boto3.resource('dynamodb')

# Reference the DynamoDB table named 'visitor-counter'
table = dynamodb.Table('visitor-counter')

# Lambda function entry point
def lambda_handler(event, context):
    try:
        # Define the primary key for the item we want to retrieve/update
        key = {'pk': 'visitor_Count'}

        # Attempt to get the current visitor count from DynamoDB
        response = table.get_item(Key=key)

        # If no item exists with this key, create it with an initial count of 0
        if 'Item' not in response:
            table.put_item(Item={'pk': 'visitor_Count', 'count': 0})

        # Atomically increment the count by 1
        update_response = table.update_item(
            Key=key,
            UpdateExpression='ADD #c :inc',  # DynamoDB ADD operation to increment numeric attribute
            ExpressionAttributeNames={'#c': 'count'},  # Placeholder for attribute name
            ExpressionAttributeValues={':inc': 1},      # Value to add
            ReturnValues='UPDATED_NEW'  # Return the updated attributes after increment
        )

        # Extract the updated count as an integer
        updated_count = int(update_response['Attributes']['count'])

        # Return a successful HTTP response with JSON body
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': 'https://staging.eivistamos.co.uk'  # CORS header for allowed domain
            },
            'body': json.dumps({'count': updated_count})  # JSON body with updated visitor count
        }

    except Exception as e:
        # Return an error response if something goes wrong
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})  # JSON body with error message
        }
